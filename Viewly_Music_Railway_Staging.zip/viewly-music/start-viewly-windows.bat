@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 22.13+ is required. Get it from https://nodejs.org/
 pause
 exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
 echo FFmpeg must be installed and available in PATH.
 echo See README.md for setup details.
 pause
 exit /b 1
)
set "PORT=4179"
set "APP_URL=http://localhost:4179"
start "Viewly local server" cmd /k "node --disable-warning=ExperimentalWarning server.js"
timeout /t 3 /nobreak >nul
start "" "http://localhost:4179"
echo Viewly running locally on this PC. Close the Viewly server window to stop.
