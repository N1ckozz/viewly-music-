# Viewly Music — product scope and next build milestones

## Rules that cannot be compromised

1. Rap, trap, drill and closely related hip-hop music only. Artist and label profiles, song releases and music-video promotion are the center of the product.
2. Viewly is independent. The user referenced Content Rewards and Whop to explain the clipping business model, **NOT** to ask for technical account linking.
3. The UI is clean near-black with white typography, controlled deep-blue highlights, micro-interactions and restrained branded 3D. The reference screenshots demonstrated layout density; do not copy foreign content.
4. No fake content, views, payouts, analytics, uploads, balances or unverifiable bot-detection claims.
5. All creators' rewards must come from funded campaign allocations; do not spend the site owner's money to cover promised creator/viewer rewards. Upfront business expenses and payment-provider liabilities still require planning.
6. Artist-owned video media is available in the public library after real upload and persistence. Promotion campaigns have additional funding gate; do not conflate public releases and paid campaigns.
7. The platform must support creators, artists/labels, clippers and fans. Users choose their role and may upgrade from viewer to artist.

## Music promotion / clipping product workflow

1. Artist registers → uploads source music video → release is publicly visible.
2. Artist creates clipping brief → defines genre/platform/editing rules/budget/reward → draft.
3. After compliant processor funding and verification, campaign becomes active.
4. Clipper picks a source video → selects segment → downloads actual vertical video clip → posts on authorized social channel with proper disclosure, permissions and credits.
5. Clipper submits public post URL and supporting proof. Platforms' metrics must not be fabricated or scraped against their terms; manual review or permissioned API integration is required.
6. Review/reward system records approval and disburses only real funded rewards, with double-spend and duplicate protection.
7. Artist receives real performance reporting; any unresolved metric must be labeled not verified, not silently presented as fact.

## Not yet implemented (priority order)

A. Robust moderated music licensing/rights flow, DMCA/takedown, abuse reporting and privacy.
B. Payout processor onboarding, KYC/identity and tax rules, holds, refund handling, ledger reconciliation, automated provider payouts, financial reviews.
C. Performance-based clipping bounties (e.g. funded pay per 1,000 **verified** offsite views), evidence/reconciliation flows and legitimate metric interfaces.
D. Public access economics: €5/month alternative or promotion milestone of 10k verified social views → permanent base access; the latter must not accept screenshots as guaranteed proof.
E. OAuth, security hardening, global rate limits, multi-device session management, account recovery and 2FA.
F. Artist-led challenges, review queues, campaign leaderboards from real stats, transparent referral program.
G. Production storage/transcoding/CDN/job queues, observability, backups and load testing.
H. Internationalization, accessible mobile navigation, quality audit, more branded 3D assets and direct music/video preview improvements.
