# VIEWLY MUSIC — independent rap / trap promotion & clipping

**A runnable application with real storage, real accounts, real publishing, and real clip generation.** This source is an initial functional build, **not a claim that a financial marketplace is certified or ready for public paid launch**.

## Product direction

Viewly serves **rappers, trappers, rap labels, their music teams, clippers, and fans**. Artists upload authorized music videos. A clipper can open the actual source, generate a **5–90 second MP4**, download it in **vertical 9:16** or original format, and submit a public post URL to an artist's clipping campaign. An artist can create a promotional brief, set a budget and a reward per approved clip, and review submissions.

**Content Rewards and Whop are conceptual references only. There is NO API connection, account link, data scraping, shared payout logic, or external dependency on either service.**

## Quick start

Requires **Node.js 22.13+** and **FFmpeg** installed on the machine. No npm packages or external services are needed for local accounts, publishing, viewing, clipping, drafts and commenting.

```bash
npm start
```

Open **http://localhost:4179** in your browser. To run automated checks:

```bash
npm test
```

The database is created at `data/viewly.sqlite`. Uploaded video and images are stored in `uploads/`. These folders are local, not automatically synced to any cloud host; **persist and back them up** before running on a server. For multi-server hosting, replace the local DB and media storage with managed equivalents.

## Working now

| Feature | Implementation |
|---|---|
| Artist / label / clipper accounts | Real users and salted scrypt password hashes |
| Persistent login | Hashed session token in HttpOnly SameSite cookie, valid up to 30 days |
| Google authentication | Actual OAuth authorization-code flow if Google credentials are configured |
| Public video uploads | Binary file stored on disk and release indexed in SQLite after upload |
| Music library | Queries actual release records; zero means zero |
| Playback and seeking | Actual video served with HTTP range support |
| Cover images | Real artist-uploaded image or generated frame from the actual video |
| Plays | Deduplicated per signed-in account/release (not fraudulent-attention certification) |
| Likes, comments | Real persistent records |
| Clipping | FFmpeg generates downloadable MP4; 9:16 with blurred background or original ratio |
| Clip library | Your actual exported files, linked to the account |
| Promotion briefs | Real campaign drafts, reward €0.50–€10, budget, 5% platform fee |
| Public campaign feed | **Only funded active campaigns**, no invented offers |
| Submissions | Actual public social post URL and optional associated exported clip |
| Reviewing submissions | Campaign owner can accept/reject when campaign is funded |
| Reward ledger | Atomic budget-deducted records; cannot allocate more than verified funds |
| Near-live updates | Server-sent event notifications + periodic reconciliation |
| Desktop/mobile UI | Responsive purpose-built UI, branded CSS vinyl visual; no stock fake creator cards |
| Payment checkout | Code path for Stripe Checkout only when genuine keys/webhook configured |
| Failed/unconfigured payments | Explicit error; **never** fake confirmation |

## Intentionally disabled or not finished

- **Public cash payouts.** There is no configured compliant payout network, so users cannot withdraw. A ledger entry is **not a bank transfer**. Do not enable real paid campaigns for the public before the payout integration, customer-verification, reconciliation, disputes and legal work are complete.
- **PayPal / Phantom wallet.** Not integrated. Any integration later must use official supported payment flows with appropriate risk, tax and eligibility review.
- **10,000-social-views access gate / €5 subscription.** Not implemented. Automated verification of social reach requires permissioned platform integrations and anti-fraud safeguards. This prototype never pretends a user has passed it.
- **Off-platform view verification / reward-per-1,000 external views.** No fake social statistics. Current campaign model uses a reward per **approved clip**, with human review. This must be extended with valid evidence or official metrics APIs for performance-based rewards.
- **Automatic anti-fraud certification.** No eye tracking, device spying, arbitrary VPN discrimination or false guarantee of human presence. Account, basic rate limits and replay protections exist, but full abuse modeling is not finished.
- **Refunds, chargebacks, payout disputes, tax reporting, age/identity verification and automated moderation.** Required before any production money flow.
- **Multi-node storage, job queue, CDN/transcoding service, virus scanning, captions, analytics warehouse, copyright workflows.** Required at scale.

## Actual payment architecture

Creators choose a budget (for example €100) and Viewly adds a **5% platform fee** (€5), so the intended checkout total is €105. On a real verified payment-provider event, the campaign receives a **€100 funded budget**, and only then becomes public. Each manually approved eligible submission deducts the designated reward from this allocation exactly once. Funds are **not manufactured by the platform**. This model does not eliminate hosting charges, payment processing fees, disputes, refunds, or other operational expenses. The owner must model and reserve for those costs.

To wire the **optional Stripe Checkout** code path for a controlled integration environment, set `APP_URL`, `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`; configure a real `POST /api/stripe/webhook` endpoint and complete all account/provider setup. **This does not enable cash payouts or make paid public launch safe.** Never publish API secrets in browser code.

## Environmental configuration

Use environment variables from `.env.example`. A plain Node process does **not** auto-load `.env` — supply variables through your runtime or deployment platform.

- `PORT`: Node server port (default 4179).
- `APP_URL`: origin used for secure origin validation and OAuth redirects. Needs HTTPS for deployment.
- `VIEWLY_DATA_DIR`: SQLite data folder (optional).
- `VIEWLY_UPLOAD_DIR`: media folder (optional).
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`: enable true Google OAuth.
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`: optional real Stripe Checkout + webhook.

## Local launch checklist

1. Start the server, create a real Artist account.
2. Upload an **original** MP4 and accept the content rights requirement.
3. Open Music from another browser: the video should be visible, playable and seekable.
4. Sign in as a Clipper; generate a vertical MP4 and download it.
5. Create an artist campaign draft; **it stays non-public until a real checkout is confirmed**.
6. Verify the wallet starts at €0.00 and there are no invented artists, posts or account balances.

## Architecture

- `server.js`: Node HTTP API, SQLite schema, password/session auth, media uploads, FFmpeg jobs, campaign state, Stripe verified webhooks, event notifications.
- `public/index.html`: application entry and loading screen.
- `public/styles.css`: desktop/mobile design system, no fake asset dependencies.
- `public/app.js`: client routing, real API calls, creator/studio/release/clip/campaign/wallet views.
- `tests/smoke.test.js`: isolated functional test of auth, upload, public availability, media seeking, comments, clips, budgets and rejection of unconfigured payments.

## Deployment limitations

This is a working local foundation and an audit-friendly development build, **not a security-certified production deployment**. Files are currently loaded into memory for upload and media stored on the local disk; these are unsuitable as-is for high-traffic, multi-tenant global operation. Add external storage, proper upload streaming, rate-limit infrastructure, CDN, email verification and recovery, media moderation, audit logging, observability, worker queue, secrets management, backup and restore before public launch. Review data privacy and copyright/legal obligations with appropriate professionals.

## Launch / quick-open update

On Windows, double-click `start-viewly-windows.bat` after installing Node.js 22.13+ and FFmpeg. It starts the **real local server** and opens `http://localhost:4179` in your browser. Alternatively, use the included `Dockerfile` and `compose.yaml` for isolated local staging. For a real public URL, connect a hosting account and complete deployment; `localhost` is not a public website. Consult `LAUNCH_READINESS.md` for the verified status and commercial launch blockers.

**Security changes:** Uploaded releases now require server-side copyright/permission attestation and FFprobe verification; OAuth state is bound to a browser cookie; paid campaign acceptance is hard-disabled until a genuine audited payout network is implemented. Even manually setting environment flags will not override this safety gate.
