# VIEWLY — Commercial Launch Readiness (23 Nov 2026)

**Status: staging/beta only. NOT production-commercial launch ready.** Do not take paid campaign deposits yet.

## Verified in this build

- Real email/password accounts and durable SQLite sessions (local or on a configured persistent server).
- Basic authenticated artist profiles, public authorized music uploads, metadata validation via FFprobe, and streaming playback.
- Real FFmpeg clip exports; likes, comments and deduplicated signed-in play counters.
- Campaign drafts and a verified-payment-only activation model, with a 5% fee calculation.
- HTTP security headers, basic origin checks, OAuth state cookie validation, user rights attestation, and payment status fail-closed when unconfigured.
- Desktop/mobile responsive interface and real empty states instead of fabricated activity.
- Automated local smoke/security checks; run `npm test`.

## Hard commercial-launch blockers

1. **Money payouts**: no Stripe Connect/other approved and verified payee onboarding, no legal model for holding/segregating artist balances, no withdrawals or reconciliation, no chargeback/refund processing. Backend payment acceptance remains **hard-disabled** in source; environment variables cannot bypass it.
2. **Social campaign verification**: no official API grant or independently reliable view metrics for TikTok/Reels/Shorts; manual clip approval cannot be represented as externally verified social reach.
3. **Hosting**: no public domain, TLS setup, hosting account/authorization, managed durable database, scalable blob storage, backups, disaster recovery or observability provisioned in this session. A local container cannot provide a persistent internet URL.
4. **Safety/compliance**: copyright takedowns and moderation/abuse queue, EU privacy/DSA notices as applicable, age/payment eligibility, tax/KYC/AML reviews, terms, paid-content disclosures, and approved provider terms are not completed.
5. **Security**: third-party penetration test, robust CSRF enforcement, verified email ownership/password reset, secrets manager, email deliverability, session management UI, global distributed rate limiting, media scanning and production incident response are pending.
6. **Economics**: fees cannot guarantee zero out-of-pocket operating cost; hosting, transcoding, payment commissions, refunds and disputes remain risks even when bounties are creator-funded.

## How to preview locally on Windows

Unzip the project. Install Node.js 22.13+ and FFmpeg and ensure they are on PATH. Double-click `start-viewly-windows.bat`. Your browser opens http://localhost:4179 on **that same PC**. This is a real local backend, not a public website; opening this address on a phone or another computer will not reach it.

Alternatively `npm start` and visit http://localhost:4179.

## Container staging (local only)

`docker compose up --build -d` serves on `http://localhost:4179` and persists SQLite/media in Docker volumes. This setup intentionally binds only to loopback and does not accept public traffic.

## Cloud staging (requires a connected hosting provider/account)

1. Put the source in a **new dedicated** Viewly repository (never overwrite unrelated repositories).
2. Create a container-backed web service with this `Dockerfile`, attach persistent disk/volume for `/app/data` and `/app/uploads`; do not expose to the public without authentication/policy review. Set `APP_URL` to the real public `https://` origin and allow the host to set `PORT`.
3. Add Google OAuth keys, callback URI and HTTPS; verify end-to-end sign-in across two devices.
4. Test backup/restore of both DB and uploads and server restart recovery.
5. Implement and audit compliant payee onboarding, payouts, refunds, disputes, legal documents, licensing/moderation, and metric verification before enabling paid campaigns.
6. Test with real provider sandbox/test accounts; then complete production credentials, approvals and launch checklist.

**Never mark the site LIVE or commercial-ready until all blockers are actually resolved and retested.**
