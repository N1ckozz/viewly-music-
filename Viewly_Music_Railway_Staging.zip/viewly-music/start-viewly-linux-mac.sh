#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
command -v node >/dev/null || { echo 'Install Node.js 22.13+'; exit 1; }
command -v ffmpeg >/dev/null || { echo 'Install FFmpeg'; exit 1; }
export PORT="${PORT:-4179}"
export APP_URL="${APP_URL:-http://localhost:4179}"
echo "Local Viewly URL: $APP_URL"
exec node --disable-warning=ExperimentalWarning server.js
