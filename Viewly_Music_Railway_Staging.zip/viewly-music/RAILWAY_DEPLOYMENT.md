# Viewly Music — Railway staging deployment

Railway project: `viewly-music`
Environment: `staging`
Service: `viewly-web`

The Railway project and empty service have been created. **No source has been deployed and no public URL exists yet.** The Railway connector can deploy a confirmed GitHub repository; it cannot receive source files directly from the assistant's container.

## Publish the source (required)

Create a **new private GitHub repository** named `viewly-music` under your GitHub account. Do not use or overwrite existing unrelated repositories. Push this folder's files to the repository's `main` branch (make sure `Dockerfile`, `package.json`, `server.js` and `public/` are in the repository root). Then connect that repository as the source of the existing Railway `viewly-web` service, using the Railway dashboard, or ask the assistant to connect it now that a concrete repository exists.

## Persistent storage (required before public testing)

Attach **one Railway persistent volume** to the `viewly-web` service at `/persistent`. Service variables are already set to `VIEWLY_DATA_DIR=/persistent/db` and `VIEWLY_UPLOAD_DIR=/persistent/uploads`. Without the volume, registrations, uploads and campaign drafts will be lost on redeploy/restart. Volumes may cost money.

## Public staging URL

After a successful deployment, use Railway's Generate Domain for `viewly-web`; then set `APP_URL=https://<actual-hostname>` in service variables and redeploy. Do not use a guessed URL. Verify `https://<actual-hostname>/api/health` responds with real status.

## Safety defaults

- `VIEWLY_PAID_MARKETPLACE_ENABLED=false`
- `VIEWLY_PAYOUTS_OPERATIONAL=false`
- `VIEWLY_LEGAL_REVIEW_COMPLETE=false`

These variables are already configured and **must stay false** until a payout integration, payment reconciliation, moderation and legal checks are complete. The source has an additional hardcoded fail-closed check: changing environment variables alone cannot enable paid campaigns.

## What still blocks commercial launch

See `LAUNCH_READINESS.md`. In particular: verified outgoing payouts, real social view verification, content rights and moderation, email verification/password recovery, payment provider compliance, security audit and reliable storage/backups. A successful deploy is staging only.

## Health and testing

Run `npm test` before deployment and after any source change. Once deployed, verify account creation, session persistence, upload/playback, clip exports, isolation across accounts, and server restart persistence. Do not accept real money or announce commercial availability based on the staging health endpoint alone.
